let descr = document.querySelector(".descriptionLife")

if(document.documentElement.clientWidth>790 && document.documentElement.clientWidth<1800){
(function($){
    $(function(){
            $(".descriptionLife").toggleClass("hidden")
    })
})(jQuery)
}